from django.contrib import admin
from .models import Expense  # import your model

admin.site.register(Expense)
